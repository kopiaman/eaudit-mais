 
<P align="center"><IMG src="images/logo_eauit.png" border="0"></P>